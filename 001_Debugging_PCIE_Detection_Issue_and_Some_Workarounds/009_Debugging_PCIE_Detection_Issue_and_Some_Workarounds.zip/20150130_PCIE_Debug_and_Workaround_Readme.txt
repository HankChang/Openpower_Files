Created by Hank 20150130,


Add some statement~



My Skiboot commit number is: 
	2e4fc3a33dab3144b19b329df91ad66871cbe952

In pci.c, please search below tags for details:

	HankPCIInfo_20150130



In phb3.h, modified the PHB3_LINK_WAIT_RETRIES form 20 to 50.
	HankPCIE_WorkaroundB_20150130


In phb3.c, please search below tags for details:

	# for more info message output:

		HankInfo_20150130



	# for bypass the IBM PHB3 special hot-plug detection:

		HankPCIE_WorkaroundA_20150130

	

	# for dynamic change the phb bridge maximum speed and width:
		
		HankPCIE_WorkaroundB_20150130

